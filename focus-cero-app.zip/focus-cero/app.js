const SUBJECTS = [
  "Matemática NS", "Economía NS", "Lenguaje", "Inglés", "Teatro",
  "TOK", "Educación Ciudadana", "Física", "PAES M1", "PAES M2",
  "PAES Competencia Lectora", "PAES Historia", "PAES Ciencias", "CAS", "Negocio"
];

const HABITS = [
  "Dormí ocho horas", "Repasé el colegio", "Hice una sesión profunda",
  "Dejé el celular lejos", "Preparé el día siguiente"
];

const STORAGE_KEY = "focusCeroDataV1";
const todayISO = () => new Date().toISOString().slice(0, 10);

const initialData = {
  energy: "media",
  studiedMinutes: 0,
  tasks: [
    { id: crypto.randomUUID(), title: "Ejercicios de ondas", subject: "Física", date: todayISO(), time: "16:40", duration: 50, priority: "high", completed: false },
    { id: crypto.randomUUID(), title: "Repaso de funciones", subject: "Matemática NS", date: todayISO(), time: "18:00", duration: 40, priority: "medium", completed: false },
    { id: crypto.randomUUID(), title: "Preparar mochila", subject: "Personal", date: todayISO(), time: "21:30", duration: 15, priority: "low", completed: false }
  ],
  habits: Object.fromEntries(HABITS.map(h => [h, false]))
};

let data = loadData();
let taskFilter = "all";
let selectedDay = new Date().getDay();
let timerSeconds = 25 * 60;
let timerInitialSeconds = timerSeconds;
let timerId = null;
let timerRunning = false;
let ceroStage = 0;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function loadData() {
  try {
    return { ...initialData, ...JSON.parse(localStorage.getItem(STORAGE_KEY)) };
  } catch {
    return structuredClone(initialData);
  }
}
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function formatDate(date = new Date()) {
  return new Intl.DateTimeFormat("es-CL", { weekday: "long", day: "numeric", month: "long" }).format(date);
}
function priorityLabel(p) {
  return { high: "Alta", medium: "Media", low: "Baja" }[p] || "Media";
}
function priorityScore(task) {
  const due = new Date(`${task.date}T23:59:59`);
  const days = Math.ceil((due - new Date()) / 86400000);
  let score = task.priority === "high" ? 5 : task.priority === "medium" ? 3 : 1;
  if (days < 0) score += 6;
  else if (days === 0) score += 10;
  else if (days === 1) score += 8;
  else if (days <= 3) score += 7;
  if (task.duration < 30) score += 1;
  return score;
}
function sortedTasks(tasks = data.tasks) {
  return [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) return Number(a.completed) - Number(b.completed);
    return priorityScore(b) - priorityScore(a) || `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`);
  });
}
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timeout);
  showToast.timeout = setTimeout(() => toast.classList.remove("show"), 2300);
}

function render() {
  $("#todayDate").textContent = formatDate().toUpperCase();
  renderToday();
  renderTasks();
  renderWeek();
  renderProgress();
  saveData();
}

function renderToday() {
  const todayTasks = sortedTasks(data.tasks.filter(t => t.date === todayISO()));
  const done = todayTasks.filter(t => t.completed).length;
  const pct = todayTasks.length ? Math.round(done / todayTasks.length * 100) : 0;
  $("#dailyPercent").textContent = `${pct}%`;
  $("#dailyRing").style.setProperty("--percent", pct);
  $("#pendingCount").textContent = todayTasks.length - done;
  const minutes = todayTasks.filter(t => !t.completed).reduce((sum, t) => sum + Number(t.duration), 0);
  $("#availableTime").textContent = `${Math.floor(minutes / 60)} h ${String(minutes % 60).padStart(2, "0")}`;

  const priority = todayTasks.find(t => !t.completed);
  $("#priorityTitle").textContent = priority?.title || "Todo completado";
  $("#priorityMeta").textContent = priority ? `${priority.subject} · ${priority.time} · ${priority.duration} min` : "Buen trabajo. Protege tu descanso.";
  $("#priorityBadge").textContent = priority ? priorityLabel(priority.priority).toUpperCase() : "LISTO";
  $("#priorityBadge").className = `badge ${priority?.priority || "low"}`;
  $("#startPriority").disabled = !priority;
  $("#startPriority").dataset.taskId = priority?.id || "";

  $("#todayTaskList").innerHTML = todayTasks.length
    ? todayTasks.map(task => taskMarkup(task, true)).join("")
    : `<div class="card"><p class="muted">No hay actividades para hoy. Agrega una en menos de tres toques.</p></div>`;
}

function taskMarkup(task, showTime = false) {
  return `<article class="${showTime ? "timeline-item" : "task-item"} ${task.completed ? "completed" : ""}">
    ${showTime ? `<span class="time">${task.time}</span>` : `<button class="check ${task.completed ? "done" : ""}" data-toggle="${task.id}" aria-label="Completar">${task.completed ? "✓" : ""}</button>`}
    <div class="task-main">
      <strong>${escapeHTML(task.title)}</strong>
      <span>${escapeHTML(task.subject)} · ${task.duration} min · ${priorityLabel(task.priority)}</span>
    </div>
    ${showTime
      ? `<button class="check ${task.completed ? "done" : ""}" data-toggle="${task.id}" aria-label="Completar">${task.completed ? "✓" : ""}</button>`
      : `<button class="delete-button" data-delete="${task.id}" aria-label="Eliminar">×</button>`}
  </article>`;
}

function renderTasks() {
  let tasks = sortedTasks();
  if (taskFilter === "pending") tasks = tasks.filter(t => !t.completed);
  if (taskFilter === "completed") tasks = tasks.filter(t => t.completed);
  $("#allTaskList").innerHTML = tasks.length
    ? tasks.map(task => taskMarkup(task)).join("")
    : `<div class="card"><p class="muted">No existen tareas en esta categoría.</p></div>`;
}

function renderWeek() {
  const base = new Date();
  const mondayOffset = (base.getDay() + 6) % 7;
  const monday = new Date(base);
  monday.setDate(base.getDate() - mondayOffset);
  const names = ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"];
  $("#weekStrip").innerHTML = names.map((name, i) => {
    const d = new Date(monday); d.setDate(monday.getDate() + i);
    return `<button class="day-pill ${d.toDateString() === base.toDateString() ? "active" : ""}" data-date="${d.toISOString().slice(0,10)}">
      <strong>${name}</strong><span>${d.getDate()}</span>
    </button>`;
  }).join("");

  const schedule = sortedTasks().slice(0, 8);
  $("#scheduleList").innerHTML = schedule.length ? schedule.map(t =>
    `<article class="schedule-block"><strong>${escapeHTML(t.title)}</strong><small>${t.date} · ${t.time} · ${escapeHTML(t.subject)}</small></article>`
  ).join("") : `<p class="muted">Tu horario aparecerá aquí.</p>`;
}

function renderProgress() {
  $("#studiedMinutes").textContent = data.studiedMinutes;
  $("#completedCount").textContent = data.tasks.filter(t => t.completed).length;

  const bySubject = {};
  data.tasks.forEach(t => {
    bySubject[t.subject] ??= { total: 0, done: 0 };
    bySubject[t.subject].total++;
    if (t.completed) bySubject[t.subject].done++;
  });
  $("#subjectProgress").innerHTML = Object.entries(bySubject).length
    ? Object.entries(bySubject).map(([subject, value]) => {
      const pct = Math.round(value.done / value.total * 100);
      return `<div class="subject-row">
        <div class="subject-label"><span>${escapeHTML(subject)}</span><strong>${pct}%</strong></div>
        <div class="bar"><span style="width:${pct}%"></span></div>
      </div>`;
    }).join("")
    : `<p class="muted">Completa tareas para ver tu progreso.</p>`;

  $("#habitList").innerHTML = HABITS.map(h =>
    `<label class="habit-row"><input type="checkbox" data-habit="${h}" ${data.habits[h] ? "checked" : ""}><span>${h}</span></label>`
  ).join("");
}

function populateSubjects() {
  const options = SUBJECTS.map(s => `<option value="${s}">${s}</option>`).join("");
  $("#taskSubject").innerHTML = options;
  $("#studySubject").innerHTML = options;
}
function openTaskDialog() {
  $("#taskDate").value = todayISO();
  $("#taskTime").value = new Date(Date.now() + 3600000).toTimeString().slice(0,5);
  $("#taskDialog").showModal();
  setTimeout(() => $("#taskTitle").focus(), 100);
}
function switchView(name) {
  $$(".view").forEach(v => v.classList.toggle("active", v.id === `view-${name}`));
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function toggleTask(id) {
  const task = data.tasks.find(t => t.id === id);
  if (!task) return;
  task.completed = !task.completed;
  showToast(task.completed ? "Tarea completada. +5 puntos ⚡" : "Tarea marcada como pendiente.");
  render();
}
function deleteTask(id) {
  data.tasks = data.tasks.filter(t => t.id !== id);
  showToast("Tarea eliminada.");
  render();
}
function escapeHTML(text) {
  return String(text).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}

function setTimer(minutes) {
  if (timerRunning) return;
  timerSeconds = Number(minutes) * 60;
  timerInitialSeconds = timerSeconds;
  updateTimerDisplay();
  $$(".timer-presets button").forEach(b => b.classList.toggle("active", Number(b.dataset.minutes) === Number(minutes)));
}
function updateTimerDisplay() {
  const min = Math.floor(timerSeconds / 60);
  const sec = timerSeconds % 60;
  $("#timerDisplay").textContent = `${String(min).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
  const elapsedRatio = 1 - timerSeconds / timerInitialSeconds;
  const stages = ["C · COMPRENDER", "E · EXTRAER", "R · RESOLVER", "O · OBSERVAR"];
  ceroStage = Math.min(3, Math.floor(elapsedRatio * 4));
  $("#ceroStep").textContent = stages[ceroStage];
}
function toggleTimer() {
  if (timerRunning) {
    clearInterval(timerId);
    timerRunning = false;
    $("#toggleTimer").textContent = "▶ Continuar";
    return;
  }
  timerRunning = true;
  $("#toggleTimer").textContent = "Ⅱ Pausar";
  timerId = setInterval(() => {
    timerSeconds--;
    updateTimerDisplay();
    if (timerSeconds <= 0) finishTimer();
  }, 1000);
}
function finishTimer() {
  clearInterval(timerId);
  timerRunning = false;
  const studied = Math.round(timerInitialSeconds / 60);
  data.studiedMinutes += studied;
  saveData();
  $("#toggleTimer").textContent = "▶ Iniciar";
  showToast(`Sesión terminada: ${studied} minutos registrados.`);
  setTimer(Math.round(timerInitialSeconds / 60));
  renderProgress();
}
function resetTimer() {
  clearInterval(timerId);
  timerRunning = false;
  timerSeconds = timerInitialSeconds;
  $("#toggleTimer").textContent = "▶ Iniciar";
  updateTimerDisplay();
}
function emergencyPlan(type) {
  const messages = {
    late: "Plan reajustado: primero las tareas urgentes y se protege tu hora de sueño.",
    busy: "Rutina mínima: 20 min prioridad + 10 min repaso + 10 min corrección.",
    tired: "Carga reducida: una prioridad y un repaso ligero."
  };
  if (type === "tired") data.energy = "baja";
  showToast(messages[type]);
  saveData();
}

document.addEventListener("click", event => {
  const nav = event.target.closest("[data-view]");
  if (nav) switchView(nav.dataset.view);
  if (event.target.closest("[data-open-task]")) openTaskDialog();

  const toggle = event.target.closest("[data-toggle]");
  if (toggle) toggleTask(toggle.dataset.toggle);

  const del = event.target.closest("[data-delete]");
  if (del) deleteTask(del.dataset.delete);

  const filter = event.target.closest("[data-filter]");
  if (filter) {
    taskFilter = filter.dataset.filter;
    $$(".filter").forEach(f => f.classList.toggle("active", f === filter));
    renderTasks();
  }

  const preset = event.target.closest("[data-minutes]");
  if (preset) setTimer(preset.dataset.minutes);

  const emergency = event.target.closest("[data-emergency]");
  if (emergency) emergencyPlan(emergency.dataset.emergency);
});

$("#taskForm").addEventListener("submit", event => {
  event.preventDefault();
  data.tasks.push({
    id: crypto.randomUUID(),
    title: $("#taskTitle").value.trim(),
    subject: $("#taskSubject").value,
    priority: $("#taskPriority").value,
    date: $("#taskDate").value,
    time: $("#taskTime").value,
    duration: Number($("#taskDuration").value),
    completed: false
  });
  $("#taskForm").reset();
  $("#taskDialog").close();
  showToast("Tarea guardada.");
  render();
});
$("#closeDialog").addEventListener("click", () => $("#taskDialog").close());
$("#toggleTimer").addEventListener("click", toggleTimer);
$("#resetTimer").addEventListener("click", resetTimer);
$("#startPriority").addEventListener("click", () => {
  const task = data.tasks.find(t => t.id === $("#startPriority").dataset.taskId);
  if (!task) return;
  $("#studySubject").value = task.subject;
  setTimer(task.duration);
  switchView("study");
});
$("#energyButton").addEventListener("click", () => {
  const order = ["alta", "media", "baja"];
  data.energy = order[(order.indexOf(data.energy) + 1) % order.length];
  showToast(`Energía del día: ${data.energy}.`);
  saveData();
});
document.addEventListener("change", event => {
  if (event.target.matches("[data-habit]")) {
    data.habits[event.target.dataset.habit] = event.target.checked;
    saveData();
  }
});

populateSubjects();
render();
updateTimerDisplay();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js"));
}

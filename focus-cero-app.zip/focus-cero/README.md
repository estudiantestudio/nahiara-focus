# Focus C.E.R.O.

PWA personal de organización académica.

## Publicar en GitHub Pages

1. Crea un repositorio público llamado `focus-cero`.
2. Sube todos los archivos de esta carpeta, sin subir el archivo ZIP.
3. Abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama **main** y la carpeta **/(root)**.
6. Guarda y espera a que GitHub muestre la dirección publicada.

## Instalar en iPhone

1. Abre la dirección publicada en Safari.
2. Presiona Compartir.
3. Presiona **Añadir a pantalla de inicio**.
4. Presiona **Añadir**.

Los datos se guardan en el navegador mediante localStorage.
